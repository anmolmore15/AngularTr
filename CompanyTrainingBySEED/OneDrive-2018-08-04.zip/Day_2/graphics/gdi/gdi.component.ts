import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'gdi',
  templateUrl: './gdi.component.html',
  styleUrls: ['./gdi.component.css']
})
export class GDIComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
