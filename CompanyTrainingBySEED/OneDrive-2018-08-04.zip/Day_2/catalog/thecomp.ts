import { Component, OnInit } from '@angular/core';
 

@Component({
  selector: 'product-list',
  template: `<h1></h1>`,
  
})
export class TheComp implements OnInit {
  constructor() {
   }

  ngOnInit() {
  }

}
