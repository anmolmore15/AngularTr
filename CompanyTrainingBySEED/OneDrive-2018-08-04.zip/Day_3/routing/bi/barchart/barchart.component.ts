import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'revenue-barchart',
  templateUrl: './barchart.component.html',
  styleUrls: ['./barchart.component.css']
})
export class BarchartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
