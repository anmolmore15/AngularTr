import { Component } from '@angular/core';

@Component({
  selector: 'tfl-root',
  templateUrl: './app.component.html',  //View of component
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Tambade Farms!';
  query: string;
}