export class Claim {
constructor(public userName:string, public password:string){
    

}
}
