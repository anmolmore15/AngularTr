
var count=0;
console.log("Hello World !");
count++;
console.log(count);

