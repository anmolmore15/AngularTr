function processData(arg) {
    return arg;
}
function processAnyData(arg) {
    return arg;
}
function processGenericsData(arg) {
    return arg;
}
var result = processGenericsData("Ravi Tambade");
console.log("Generics Data  :" + result);
//# sourceMappingURL=genericsTest.js.map