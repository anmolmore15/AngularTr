


function greeter(person) {
    return "Hello, " + person;
}

var user = "Ravi Tambade";

document.body.innerHTML = greeter(user);     