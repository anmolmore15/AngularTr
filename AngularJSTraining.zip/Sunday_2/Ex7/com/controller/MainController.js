
myModule.controller('MainController', ["$scope", "$filter",
	function($scope,$filter) 
{
		$scope.username = 'default';

}]);