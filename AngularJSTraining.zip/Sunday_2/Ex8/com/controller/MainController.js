
myModule.controller('MainController', ["$scope", "$filter",
	function($scope,$filter) 
{
		//$scope.firstname = 'default';
        //$scope.email = 'test@test.com'
}]);