myModule.constant('clientId','SourceCode');
myModule.value('clientName','ABCDEFG12345');